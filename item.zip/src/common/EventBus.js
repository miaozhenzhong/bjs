import Vue from 'Vue'

var _bus = new Vue();

export var bus = _bus  