var _commuConfig = {
  timeout:600*1000,
  baseUrl: 'api/v1'
  // filebaseUrl: 'http://cria.cdb.com.cn'  gtjf.com.cn:8090
}//10.55.15.179
export var commuConfig = _commuConfig
