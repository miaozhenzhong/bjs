<template>
    <div>
        <el-button size="mini">IAAD检查</el-button>
        <div >
            
            <img src="../../assets/1.jpg"/>
        </div>
    </div>
</template>
<script>
export default {
  name: 'IAADCheck',
  data () {
    return {}
  }
}
</script>
<style lang="scss" scoped>

</style>

