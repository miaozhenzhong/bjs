<template>
    <div>
        <el-button>IAADresult</el-button>
    </div>
</template>
<script>
export default {
  name: 'IAADResult',
  data () {
    return {}
  },
  beforeRouteLeave (to, from , next) {
    next();
  }
}
</script>
<style lang="scss" scoped>

</style>

