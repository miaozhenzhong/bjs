<template>
    <div>
        <el-button>结果查询</el-button>
    </div>
</template>
<script>
export default {
  name: 'RaiseResult',
  data () {
    return {}
  }
}
</script>
<style lang="scss" scoped>

</style>

